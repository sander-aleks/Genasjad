import API from './api/api.js';

// API.get('/countries').then((response) => console.log(response.data.response));

const countrySelectElement = document.querySelector('#countries');
// const resultWrapper = document.querySelector('.result');
// const emptyStateWrapper = document.querySelector('')

countrySelectElement.add(new Option('', null, true))
try {
    API.get('/countries').then((response) => {
        response.data.response.forEach((country) => {
            countrySelectElement.add(new Option(country, country));
        })
    });
    
} catch (error) {
    throw new Error(error.response.message)
}
 